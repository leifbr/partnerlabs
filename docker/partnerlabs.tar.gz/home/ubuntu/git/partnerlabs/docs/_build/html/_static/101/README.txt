This folder contains the images for the LTM Fundamentals course
